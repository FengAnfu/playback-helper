# Playback Helper: windows

Before use, replace every required CONFIGURE_* identifier and control label in the source and rebuild as needed. No target application is configured.

Start with windows/README.md for file locations, identifier replacement instructions, and platform requirements.
Source: https://github.com/FengAnfu/playback-helper-clean
